set pages 200 lines 200
col username for a30
col machine for a30
COLUMN DUMMY NOPRINT;
COMPUTE SUM OF NUM_OF_PORCESS ON DUMMY;
BREAK ON DUMMY;
select NULL DUMMY,nvl(s.username,'BACKGROUND') as username,s.machine,count(p.spid) as NUM_OF_PORCESS from v$session s,v$process p where s.paddr(+)=p.addr group by s.username,s.machine;