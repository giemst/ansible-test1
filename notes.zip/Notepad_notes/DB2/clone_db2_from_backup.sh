
db2 "backup database DMCTEST1 online to /software/data01/db2inst/backup compress include logs"

db2 list history backup all for DMCTEST1
db2ckbkp -h DMCTEST1.0.db2inst.DBPART000.20230830134106.001

db2 "restore database DMCTEST1 from /software/data01/db2inst/backup taken at 20230831103046 to /software/data01 into DMCTEST2 LOGTARGET DEFAULT"
db2 "ROLLFORWARD DB DMCTEST2 TO END OF LOGS AND COMPLETE"

# to check rollfoorward status
db2 rollforward db dmctest2 query status