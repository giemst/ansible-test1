### BACKUP 

  db2 list history backup all for sample

  ## Offline backup 

    # Before OFF line backup disconnect application and stop database

    db2 list applications
    db2 force applications all
    db2 terminate
    db2 deactivate database sample

    # run backup, validate backup 

    db2 backup database sample to /software/db2usr/BACKUPS compress
    db2ckbkp -h SAMPLE.0.db2usr.DBPART000.20220603133620.001

    # start database

    db2 activate database sample

  ## Online BACKUP
    # Ensure that database archive logings is setup correctly
    db2 get db cfg for sample| grep LOG

    # First log archive method                 (LOGARCHMETH1) = DISK:/software/db2usr/BACKUPS
    # Archive compression for logarchmeth1    (LOGARCHCOMPR1) = ON
    db2 "update db cfg for sample using LOGARCHMETH1 DISK:/software/db2usr/DB_ARCH_LOGS IMMEDIATE"
    db2 "update db cfg for sample using LOGARCHCOMPR1 ON IMMEDIATE"

    db2 "backup database sample online to /software/db2usr/BACKUPS compress include logs"


## Commvault agent property file on the DB2 host server 

/etc/CommVaultRegistry/Galaxy/Instance001/Db2Agent/.properties

