How to chake MQ queues
On Linux, if you have both GTK2 and GTK3 installed on your system then you must disable GTK3 with the environment variable SWT_GTK3=0.


dmpmqcfg -t queue  -m QM_SAMPLE|grep DEFINE|grep -vi SYSTEM

DEFINE QLOCAL('ASN.ADMINQ') +
DEFINE QREMOTE('ASN.QSRC_TO_ASN.QTGT.DATA') +
DEFINE QLOCAL('ASN.RESTARTQ') +
DEFINE QLOCAL('QM_ONE') +

DEFINE QREMOTE('ASN.ADMINQ') +
DEFINE QLOCAL('ASN.QSRC_TO_ASN.QTGT.DATA') +
DEFINE QMODEL('IBMQREP.SPILL.MODELQ') +
DEFINE QLOCAL('QM_SAMPLE') +

