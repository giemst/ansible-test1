on linux ? then go to this path /db2db/db2ins01/db2dump/QReplication

to check the status :
./appmondet.sh

to start apply: 
runapply.sh

to stop : 
asnqacmd apply_server=<db_name> apply_schema=asn stop