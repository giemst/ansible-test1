# create new certificate request:

cd /home/db2inst1/keystore/dmc
openssl req -new -newkey rsa:2048 -nodes -keyout server.key -out server.csr

# Enter following info :
# =========

# Country Name (2 letter code) [XX]:DK
# State or Province Name (full name) []:DK
# Locality Name (eg, city) [Default City]:Copenhagen
# Organization Name (eg, company) [Default Company Ltd]:Danske Bank A/S
# Organizational Unit Name (eg, section) []:Z3-DS
# Common Name (eg, your name or your server's hostname) []:yb7995.danskenet.net
# Email Address []:
# 
# Please enter the following 'extra' attributes
# to be sent with your certificate request
# A challenge password []:dbdb1234
# An optional company name []:
# 
# ==========
 
# -- check content of certificate request file :
openssl req -text -in server.csr -noout

# copy/paste certivicate request to icert.danskenet.net
# copy/paste new generated certificate into new file yb7995.crt

# convert certificate into pksc12 format :
openssl pkcs12 -export -in yb7995.crt -inkey server.key -out cert.p12

# create encrypted token based on certificate password :
/db2home/ibm-datamgmtconsole/dsutil/bin/libertyCertsCrypt.sh 'dbdb1234'

# set properties in 
vi /db2home/ibm-datamgmtconsole/wlp/usr/servers/dsweb/bootstrap.properties

#=====
# wlp.keystore.type=pkcs12
# wlp.keystore.location=/home/db2inst1/keystore/dmc
# wlp.keystore.password=<put generated token here>
#
# !! to disable http set !!
# port=-1 
#====

# restart DMC 

/db2home/ibm-datamgmtconsole/bin/restart.sh