## create new file /etc/pam.d/db2

[db2inst1@yb7995 cfg]$ cat /etc/pam.d/db2
#%PAM-1.0
auth       required     pam_sepermit.so
auth       substack     password-auth
auth       include      postlogin
# Used with polkit to reauthorize users in remote sessions
-auth      optional     pam_reauthorize.so prepare
account    required     pam_nologin.so
account    include      password-auth
password   include      password-auth
# pam_selinux.so close should be the first session rule
session    required     pam_selinux.so close
session    required     pam_loginuid.so
# pam_selinux.so open should only be followed by sessions to be executed in the user context
session    required     pam_selinux.so open env_params
session    required     pam_namespace.so
session    optional     pam_keyinit.so force revoke
session    include      password-auth
session    include      postlogin
# Used with polkit to reauthorize users in remote sessions
-session   optional     pam_reauthorize.so prepare

## create new file $DB@HOME/sqllib/cfg/IBMLDAPSecurity.ini

[db2inst1@yb7995 cfg]$ cat IBMLDAPSecurity.ini
LDAP_HOST = danskenet.net

ENABLE_SSL = false

USER_OBJECTCLASS = user
USER_BASEDN = DC=danskenet,DC=net
USERID_ATTRIBUTE = sAMAccountName
AUTHID_ATTRIBUTE = sAMAccountName

GROUP_OBJECTCLASS = group
GROUP_BASEDN = DC=danskenet,DC=net
GROUPNAME_ATTRIBUTE = cn
GROUP_LOOKUP_METHOD = SEARCH_BY_DN
GROUP_LOOKUP_ATTRIBUTE  = member

SEARCH_DN = d000273@DANSKENET.NET
SEARCH_PW = S08-GciLXGkzeF@Q


[db2inst1@yb7995 cfg]$ chmod 640 IBMLDAPSecurity.ini


## update database manager configuration to enambe LDAP authentication


[db2inst1@yb7995 ~]$ db2 update dbm cfg using GROUP_PLUGIN IBMLDAPgroups
DB20000I  The UPDATE DATABASE MANAGER CONFIGURATION command completed
successfully.
[db2inst1@yb7995 ~]$ db2 update dbm cfg using SRVCON_PW_PLUGIN IBMLDAPauthserver
DB20000I  The UPDATE DATABASE MANAGER CONFIGURATION command completed
successfully.

## restart instance

[db2inst1@yb7995 ~]$ db2stop

[db2inst1@yb7995 ~]$ db2start