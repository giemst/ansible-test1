db2pd -alldbs -tablespaces
db2pd -db DMVTEST2 -tablespaces
db2 list tablespaces
db2 list tablespaces for dmctest2

mkdir -p /software/data01/strgroup1/DMCTEST1
db2 "create stogroup GM_STOGRP on '/software/data01/strgroup1/DMCTEST1'"
db2 "select * from syscat.stogroups"
db2 "alter stogroup gm_stogrp SET AS DEFAULT"

db2pd -db TUVOSFP1 -storagegroup


db2 "ALTER TABLESPACE gmtest1 MANAGED BY AUTOMATIC STORAGE USING STOGROUP GM_STOGRP"

db2 list tablespaces show detail
db2 list tablespace containers for 3 show detail



db2 "alter stogroup gm_stogrp add '/software/data01'"
db2 "alter stogroup gm_stogrp drop '/software/data01/strgroup1/DMCTEST1'"
db2 "alter tablespace GMTEST1 rebalance"


db2 "select * from power.gm2"
