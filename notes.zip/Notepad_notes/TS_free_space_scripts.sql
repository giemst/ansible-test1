-- Custom script

select t.tablespace_name, t.allocated, t.maxsize, f.alloc_free, t.maxsize-t.allocated+f.alloc_free realfree, round((t.maxsize-(t.maxsize-t.allocated+f.alloc_free))/t.maxsize*100) PCT_used, maxsize-allocated disk_demand
from (select tablespace_name, round(sum(bytes)/1024/1024/1024,2) allocated, round(sum(case when AUTOEXTENSIBLE='YES' then MAXBYTES
    else bytes end)/1024/1024/1024,2) MAXSIZE from dba_data_files group by tablespace_name) t,
     (select TABLESPACE_NAME,round(sum(bytes)/1024/1204/1024,2) alloc_free from dba_free_space group by tablespace_name) f
where t.tablespace_name = f.tablespace_name (+);



-- Oracle default metrics usage - simply converted into Gigabytes instead of blocks

SELECT tbm.TABLESPACE_NAME,
   round(tbm.USED_SPACE * tb.BLOCK_SIZE /(1024*1024*1024),2) USED_SPACE_GB,
   round(tbm.TABLESPACE_SIZE * tb.BLOCK_SIZE /(1024*1024*1024),2) TABLESPACE_SIZE_GB,
   round((tbm.TABLESPACE_SIZE - tbm.USED_SPACE) * tb.BLOCK_SIZE /(1024*1024*1024),2) TABLESPACE_FREE_SIZE_GB,
   tbm.USED_PERCENT
FROM dba_tablespace_usage_metrics tbm
     join dba_tablespaces tb on tb.TABLESPACE_NAME = tbm.TABLESPACE_NAME
;
