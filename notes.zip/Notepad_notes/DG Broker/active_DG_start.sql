SQL> alter database recover managed standby database cancel;
SQL> alter database open;
SQL> alter database recover managed standby database using current logfile disconnect from session;

http://pafumi.net/Active_Data_Guard.html

DGMGRL> edit database 'STDBY' set state = 'apply-off';

sqlplus> alter database open read only;

DGMGRL> edit database 'STDBY' set state = 'apply-on';


 
