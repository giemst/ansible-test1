ALTER DATABASE CREATE DATAFILE
'/software/app/oracle/product/19.0.0/dbhome_1/dbs/UNNAMED00312'
as
'/u05/app/oracle/oradata/DPRO/scindx_097.dbf';
