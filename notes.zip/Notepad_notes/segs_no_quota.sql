select distinct s.owner,s.tablespace_name,decode(max_bytes,-1,'O.K.',null,'NO QUOTA') "ISOK"  from dba_segments s,dba_ts_quotas q
where s.owner in ('CDR','CGR','CSR','SAS_GRP_GER_RPT','SAS_GRP_GER_USER','SAS_GRP_SWE_RPT')
and s.owner=q.username(+)
and s.tablespace_name=q.tablespace_name(+)
and decode(max_bytes,-1,'O.K.',null,'NO QUOTA')  !='O.K.'
order by 1,2;
