lvcreate -n redo1lv -L 20G datavg
lvcreate -n redo2lv -L 20G datavg
lvcreate -n fra1lv -L 500G datavg
lvcreate -n oradata1lv -L 3072G datavg
lvcreate -n oraswlv -L 100G datavg
lvcreate -n dbdumplv -l 100% datavg


mkfs.xfs /dev/datavg/redo1lv
mkfs.xfs /dev/datavg/redo2lv
mkfs.xfs /dev/datavg/fra1lv
mkfs.xfs /dev/datavg/oradata1lv
mkfs.xfs /dev/datavg/oraswlv
mkfs.xfs /dev/datavg/dbdumplv

cat >> /etc/fstab << XXX
/dev/mapper/datavg-redo1lv  /u01/app/oracle/oradata/FDWH00P1/redo             xfs             defaults 0 0 
/dev/mapper/datavg-redo2lv  /u02/app/oracle/oradata/FDWH00P1/redo            xfs             defaults 0 0 
/dev/mapper/datavg-fra1lv    /u03/app/oracle/fast_recovery_area/FDWH00P1       xfs             defaults 0 0        
/dev/mapper/datavg-oradata1lv   /u05/app/oracle/oradata/FDWH00P1               xfs             defaults 0 0  
/dev/mapper/datavg-oraswlv      /software                                 xfs             defaults 0 0
/dev/mapper/datavg-dbdumplv     /u04/app/oracle/export                    xfs             defaults 0 0 
XXX

mkdir -p /u01/app/oracle/oradata/FDWH00P1/redo
mkdir -p /u02/app/oracle/oradata/FDWH00P1/redo
mkdir -p /u03/app/oracle/fast_recovery_area/FDWH00P1
mkdir -p /u05/app/oracle/oradata/FDWH00P1
mkdir -p /software
mkdir -p /u04/app/oracle/export

mount -a

chown -R oracle:oinstall /software
chown -R oracle:oinstall /u01
chown -R oracle:oinstall /u02
chown -R oracle:oinstall /u03
chown -R oracle:oinstall /u04
chown -R oracle:oinstall /u05


swapoff -a
lvresize -L 16g /dev/systemvg/swaplv
mkswap /dev/systemvg/swaplv
swapon -a
free -g