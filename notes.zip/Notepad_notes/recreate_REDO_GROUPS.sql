 alter database drop logfile group 1;
 alter database drop logfile group 2;
 alter database drop logfile group 3;

 alter database add logfile group 2 ('/u01/app/oracle/oradata/PLA000S1/redo/PLA000S1_redo2a.log','/u02/app/oracle/oradata/PLA000S1/redo/PLA000S1_redo2b.log') size 200M;
 alter database add logfile group 1 ('/u01/app/oracle/oradata/PLA000S1/redo/PLA000S1_redo1a.log','/u02/app/oracle/oradata/PLA000S1/redo/PLA000S1_redo1b.log') size 200M;
 alter database add logfile group 3 ('/u01/app/oracle/oradata/PLA000S1/redo/PLA000S1_redo3a.log','/u02/app/oracle/oradata/PLA000S1/redo/PLA000S1_redo3b.log') size 200M;
