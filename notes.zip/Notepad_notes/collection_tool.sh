
cd /home/bc8510/Collection/bin
mkdir /tmp/collection_output
rm output/*.bz2
./Collection.sh -d / -L Y -p DB -t /tmp/collection_output

cp output/*.bz2 /tmp/collection_output
chmod -R 777 /tmp/collection_output
ls -al /tmp/collection_output
