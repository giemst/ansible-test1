select 'set newname for datafile '||file#||' to '''||replace(name,(select name from v$database),'CIO00SD2')||''';' from v$datafile;
select 'set newname for datafile '||file#||' to '''||replace(replace(name,(select name from v$database),'scp00sp1'),'/dbo','+ASM_DATA_01')||''';' from v$datafile;
select 'set newname for tempfile '||file#||' to '''||replace(name,(select name from v$database),'CIO00SD2')||''';' from v$tempfile;

declare
      print_var varchar2(200);
      cursor c1 is select member from gv$logfile where inst_id = 1
      order by group#;
      logfile gv$logfile.member%TYPE;
      cursor c2 is select bytes from gv$log where inst_id = 1
      order by group#;
      bytes number;
      lsize varchar2(30);
  begin
      open c1;
      open c2;
      for record in (
      select group#, count(*) members from gv$logfile where inst_id = 1
      group by group# order by 1) loop
           dbms_output.put_line(print_var);
           fetch c2 into bytes;
           if mod(bytes,1024) = 0 then
              if mod(bytes,1024*1024) = 0 then
                 lsize := to_char(bytes/(1024*1024))||'M';
              else
                 lsize := to_char(bytes/1024)||'K';
              end if;
           else
              lsize := to_char(bytes);
           end if;
           lsize := lsize||',';
           if record.members > 1 then
             fetch c1 into logfile;
             print_var := 'GROUP '||record.group#||' (';
             dbms_output.put_line(print_var);
             print_var := ''''||logfile||''''||',';
             for i in 2..record.members loop
                 fetch c1 into logfile;
                 dbms_output.put_line(print_var);
                 print_var := ''''||logfile||''''||',';
             end loop;
             print_var := rtrim(print_var,',');
             dbms_output.put_line(print_var);
             print_var := ') SIZE '||lsize;
           else
             fetch c1 into logfile;
             print_var := 'GROUP '||record.group#||' '''||
                          logfile||''''||' SIZE '||lsize;
           end if;
      end loop;
      close c1;
      close c2;
      print_var := rtrim(print_var,',');
      dbms_output.put_line(print_var);
  end;
/

