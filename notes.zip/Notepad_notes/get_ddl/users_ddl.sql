set long 20000 longchunksize 20000 pagesize 0 linesize 1000 feedback off verify off trimspool on
column ddl format a1000

begin
   dbms_metadata.set_transform_param (dbms_metadata.session_transform, 'SQLTERMINATOR', true);
   dbms_metadata.set_transform_param (dbms_metadata.session_transform, 'PRETTY', true);
end;
/

select dbms_metadata.get_ddl('USER', u.username) AS ddl
from   dba_users u where username not in ('SYS','SYSTEM');

select dbms_metadata.get_granted_ddl('SYSTEM_GRANT', sp.grantee) AS ddl
from   dba_sys_privs sp
where  sp.grantee not in ('SYS','SYSTEM');

select dbms_metadata.get_granted_ddl('SYSTEM_GRANT', 'FDR') from dual;





select dbms_metadata.get_ddl('TABLE', 'SHC_BA', 'FWH') from dual;

alter system set events = '31151 trace name context forever, level 0x2000000' scope=memory;