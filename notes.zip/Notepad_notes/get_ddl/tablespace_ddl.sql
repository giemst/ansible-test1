SET LONG 20000 LONGCHUNKSIZE 20000 PAGESIZE 0 LINESIZE 1000 FEEDBACK OFF VERIFY OFF TRIMSPOOL ON
BEGIN
   DBMS_METADATA.set_transform_param (DBMS_METADATA.session_transform, 'SQLTERMINATOR', true);
   DBMS_METADATA.set_transform_param (DBMS_METADATA.session_transform, 'PRETTY', true);
   DBMS_METADATA.set_transform_param (DBMS_METADATA.session_transform, 'REUSE', true);
   DBMS_METADATA.set_transform_param (DBMS_METADATA.session_transform, 'PCTSPACE', true);
END;
/
SELECT DBMS_METADATA.GET_DDL('TABLESPACE',tablespace_name) FROM dba_tablespaces;