select
   os_username,
   username,
   userhost,
   returncode, count(*)
from
   dba_audit_trail
where   timestamp > sysdate -1/24 and returncode != 0
group by os_username,
   username,
   userhost,
   returncode;
