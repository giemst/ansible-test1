CREATE PROFILE APPL_OWNER
    LIMIT
         FAILED_LOGIN_ATTEMPTS 4
         PASSWORD_LIFE_TIME UNLIMITED
         PASSWORD_REUSE_TIME 365
         PASSWORD_REUSE_MAX 20
         PASSWORD_VERIFY_FUNCTION "ORA12C_STRONG_VERIFY_FUNCTION"
         PASSWORD_LOCK_TIME UNLIMITED
         PASSWORD_GRACE_TIME 5;


         CREATE PROFILE MONITORING_PROFILE
          LIMIT
          FAILED_LOGIN_ATTEMPTS 4
          PASSWORD_LIFE_TIME UNLIMITED
          PASSWORD_REUSE_TIME 365
          PASSWORD_REUSE_MAX 20
          PASSWORD_VERIFY_FUNCTION "ORA12C_STRONG_VERIFY_FUNCTION"
          PASSWORD_LOCK_TIME UNLIMITED
          PASSWORD_GRACE_TIME 5;

alter user rman profile appl_owner;
alter user dbsnmp profile MONITORING_PROFILE;

create tablespace AUDIT_TS datafile '/u05/app/oracle/oradata/FRP000S1/audit_ts_01.dbf' size 1g autoextend on next 1g maxsize unlimited;

BEGIN
DBMS_AUDIT_MGMT.SET_AUDIT_TRAIL_LOCATION(
       audit_trail_type => DBMS_AUDIT_MGMT.AUDIT_TRAIL_DB_STD,
       audit_trail_location_value =>  'AUDIT_TS');
END;
/
