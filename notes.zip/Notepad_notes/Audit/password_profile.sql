set serveroutput on
begin
for i in (SELECT 'alter user '||username||' identified by "0th3r_Pa55"' tx FROM DBA_USERS_WITH_DEFPWD WHERE USERNAME NOT in ( '%XS$NULL%','DBSNMP' )) loop
execute immediate i.tx;
dbms_output.put_line(i.tx);
end loop;
end;
/
************************************************************************************************************
1. create password verify function

create or replace function sys.ora_complexity_check
(password varchar2,
chars integer := null,
letter integer := null,
upper integer := null,
lower integer := null,
digit integer := null,
special integer := null)
return boolean is
   digit_array varchar2(10) := '0123456789';
   alpha_array varchar2(26) := 'abcdefghijklmnopqrstuvwxyz';
   cnt_letter integer := 0;
   cnt_upper integer := 0;
   cnt_lower integer := 0;
   cnt_digit integer := 0;
   cnt_special integer := 0;
   delimiter boolean := false;
   len integer := nvl (length(password), 0);
   i integer ;
   ch char(1);
begin
   -- Check that the password length does not exceed 2 * (max DB pwd len)
   -- The maximum length of any DB User password is 128 bytes.
   -- This limit improves the performance of the Edit Distance calculation
   -- between old and new passwords.
   if len > 256 then
      raise_application_error(-20020, 'Password length more than 256 characters');
   end if;

   -- Classify each character in the password.
   for i in 1..len loop
      ch := substr(password, i, 1);
      if ch = '"' then
         delimiter := true;
      elsif instr(digit_array, ch) > 0 then
         cnt_digit := cnt_digit + 1;
      elsif instr(alpha_array, nls_lower(ch)) > 0 then
         cnt_letter := cnt_letter + 1;
         if ch = nls_lower(ch) then
            cnt_lower := cnt_lower + 1;
         else
            cnt_upper := cnt_upper + 1;
         end if;
      else
         cnt_special := cnt_special + 1;
      end if;
   end loop;

   if delimiter = true then
      raise_application_error(-20012, 'password must NOT contain a '
                               || 'double-quotation mark which is '
                               || 'reserved as a password delimiter');
   end if;
   if chars is not null and len < chars then
      raise_application_error(-20001, 'Password length less than ' ||
                              chars);
   end if;

   if letter is not null and cnt_letter < letter then
      raise_application_error(-20022, 'Password must contain at least ' ||
                                      letter || ' letter(s)');
   end if;
   if upper is not null and cnt_upper < upper then
      raise_application_error(-20023, 'Password must contain at least ' ||
                                      upper || ' uppercase character(s)');
   end if;
   if lower is not null and cnt_lower < lower then
      raise_application_error(-20024, 'Password must contain at least ' ||
                                      lower || ' lowercase character(s)');
   end if;
   if digit is not null and cnt_digit < digit then
      raise_application_error(-20025, 'Password must contain at least ' ||
                                      digit || ' digit(s)');
   end if;
   if special is not null and cnt_special < special then
      raise_application_error(-20026, 'Password must contain at least ' ||
                                      special || ' special character(s)');
   end if;

   return(true);
end;
/

create or replace function sys.ora_string_distance
(s varchar2,
t varchar2)
return integer is
   s_len    integer := nvl (length(s), 0);
   t_len    integer := nvl (length(t), 0);
   type arr_type is table of number index by binary_integer;
   d_col    arr_type ;
   dist     integer := 0;
begin
   if s_len = 0 then
      dist := t_len;
   elsif t_len = 0 then
      dist := s_len;
   -- Bug 18237713 : If source or target length exceeds max DB password length
   -- that is 128 bytes, then raise exception.
   elsif t_len > 128 or s_len > 128 then
     raise_application_error(-20027,'Password length more than 128 bytes');
   elsif s = t then
     return(0);
   else
      for j in 1 .. (t_len+1) * (s_len+1) - 1 loop
          d_col(j) := 0 ;
      end loop;
      for i in 0 .. s_len loop
          d_col(i) := i;
      end loop;
      for j IN 1 .. t_len loop
          d_col(j * (s_len + 1)) := j;
      end loop;

      for i in 1.. s_len loop
        for j IN 1 .. t_len loop
          if substr(s, i, 1) = substr(t, j, 1)
          then
             d_col(j * (s_len + 1) + i) := d_col((j-1) * (s_len+1) + i-1) ;
          else
             d_col(j * (s_len + 1) + i) := LEAST (
                       d_col( j * (s_len+1) + (i-1)) + 1,      -- Deletion
                       d_col((j-1) * (s_len+1) + i) + 1,       -- Insertion
                       d_col((j-1) * (s_len+1) + i-1) + 1 ) ;  -- Substitution
          end if ;
        end loop;
      end loop;
      dist :=  d_col(t_len * (s_len+1) + s_len);
   end if;

   return (dist);
end;
/

Create or replace function sys.ora12c_strong_verify_function
(username varchar2,
password varchar2,
old_password varchar2)
return boolean IS
   differ integer;
begin
   if not ora_complexity_check(password, chars => 8, upper => null, lower => null,
                           digit => 1, special => 1) then
      return(false);
   end if;
   -- Check if the password differs from the previous password by at least
   -- 4 characters
   if old_password is not null then
      differ := ora_string_distance(old_password, password);
      if differ < 4 then
         raise_application_error(-20032, 'Password should differ from previous '
                                 || 'password by at least 4 characters');
      end if;
   end if;
   return(true);
end;
/
**********************************************************************************************************
2. set function to all profiles ---???? possible not on appl_owner
set serveroutput on
begin
for i in (select distinct 'alter profile '||profile||' limit  PASSWORD_VERIFY_FUNCTION ORA12C_STRONG_VERIFY_FUNCTION ' tx from dba_profiles) loop
execute immediate i.tx;
dbms_output.put_line(i.tx);
end loop;
end;
/

select distinct profile, limit  tx from dba_profiles where RESOURCE_NAME='PASSWORD_VERIFY_FUNCTION';

******************************************************************************************************
3. set FAILED_LOGIN_ATTEMPTS 4 or less
set serveroutput on
begin
for i in (select distinct 'alter profile '||profile||' limit FAILED_LOGIN_ATTEMPTS 4' tx from dba_profiles where RESOURCE_NAME='FAILED_LOGIN_ATTEMPTS' and limit != 'DEFAULT' and limit>4) loop
execute immediate i.tx;
dbms_output.put_line(i.tx);
end loop;
end;
/
*************************************************************************************************
4. set PASSWORD_LOCK_TIME setting
set serveroutput on
begin
for i in (select distinct 'alter profile '||profile||' limit PASSWORD_LOCK_TIME UNLIMITED' tx from dba_profiles
          where RESOURCE_NAME='PASSWORD_LOCK_TIME' and decode(limit,'UNLIMITED',9999,'DEFAULT',0,limit)<1) loop
execute immediate i.tx;
dbms_output.put_line(i.tx);
end loop;
end;
/
*********************************************************************************************************************
!!!!! here need to check application profile names as per database/application

5. set PASSWORD_LIFE_TIME 90 or more (exlude APPL_OWNER, MONITORUNG_PROFILE)
set serveroutput on
begin
for i in (select distinct 'alter profile '||profile||' limit PASSWORD_LIFE_TIME 90' tx from dba_profiles
          where RESOURCE_NAME='PASSWORD_LIFE_TIME' and decode(limit,'UNLIMITED',9999,'DEFAULT',9999,limit)>90
                                  and profile not in ('APPL_OWNER','MONITORING_PROFILE','MONITORING')) loop
execute immediate i.tx;
dbms_output.put_line(i.tx);
end loop;
end;
/
!!!!! here need to check application profile names
*********************************************************************************************************************
6. set PASSWORD_REUSE_MAX 20 or more
set serveroutput on
begin
for i in (select distinct 'alter profile '||profile||' limit PASSWORD_REUSE_MAX 20' tx from dba_profiles
          where RESOURCE_NAME='PASSWORD_REUSE_MAX' and decode(limit,'UNLIMITED',0,'DEFAULT',0,limit)<20) loop
execute immediate i.tx;
dbms_output.put_line(i.tx);
end loop;
end;
/
********************************************************************************************
7. set PASSWORD_REUSE_TIME 365 or more
set serveroutput on
begin
for i in (select distinct 'alter profile '||profile||' limit PASSWORD_REUSE_TIME 365' tx from dba_profiles
          where RESOURCE_NAME='PASSWORD_REUSE_TIME' and decode(limit,'UNLIMITED',0,'DEFAULT',0,limit)<365) loop
execute immediate i.tx;
dbms_output.put_line(i.tx);
end loop;
end;
/
**************************************************************************************************************************
8. set PASSWORD_GRACE_TIME 5 or less
set serveroutput on
begin
for i in (select distinct 'alter profile '||profile||' limit PASSWORD_GRACE_TIME 5' tx from dba_profiles
          where RESOURCE_NAME='PASSWORD_GRACE_TIME' and decode(limit,'UNLIMITED',9999,'DEFAULT',9999,limit)>5) loop
execute immediate i.tx;
dbms_output.put_line(i.tx);
end loop;
end;
/
**********************************************************************************************************
