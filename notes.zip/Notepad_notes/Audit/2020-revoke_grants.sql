select GRANTEE,PRIVILEGE from dba_sys_privs where PRIVILEGE in ('SELECT ANY DICTIONARY','SELECT ANY TABLE','AUDIT SYSTEM','EXEMPT ACCESS POLICY','BECOME USER','CREATE PROCEDURE',
'CREATE ANY LIBRARY','CREATE LIBRARY','GRANT ANY OBJECT PRIVILEGE') and grantee in (select username from dba_users where oracle_maintained='N') order by 2;

select grantee,granted_role from dba_role_privs where GRANTED_ROLE in ('SELECT_CATALOG_ROLE','DELETE_CATALOG_ROLE','SELECT_CATALOG_ROLE','EXECUTE_CATALOG_ROLE','DBA')
and grantee in (select username from dba_users where oracle_maintained='N');

select grantee,owner,table_name from dba_tab_privs where table_name in ('AUD$','USER_HISTORY$','LINK$','SYS.USER$','SCHEDULER$_CREDENTIAL')
or table_name like 'DBA_%' and grantee in (select username from dba_users where oracle_maintained='N') ;


select grantee,privilege from dba_sys_privs where privilege like '%ANY%' and
grantee in (
select username from dba_users where oracle_maintained='N'
union all
select role from dba_roles where oracle_maintained='N') order by 1,2;


select * from dba_sys_privs where admin_option='YES' and
grantee in (
select username from dba_users where oracle_maintained='N'
union all
select role from dba_roles where oracle_maintained='N') order by 1,2;
