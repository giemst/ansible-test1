audit user ;
audit alter user ;
audit drop user ;
audit role ;
audit system grant;
audit profile ;
audit drop profile ;
audit alter profile ;
audit database link ;
audit public database link ;
audit public synonym ;
audit synonym ;
audit grant directory ;
audit select any dictionary ;
audit GRANT ANY PRIVILEGE ;
audit drop any procedure ;
audit all on sys.aud$ ;
audit procedure ;
audit alter system ;
audit trigger ;
audit create TRIGGER ;
audit trigger ;
audit create session ;



