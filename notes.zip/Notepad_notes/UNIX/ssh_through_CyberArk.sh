ssh bc8510@bc8510@wk1151#22@PsmpDblanVip.danskenet.net

host key failed workaround :

ssh -o "UserKnownHostsFile=/dev/null" -o "StrictHostKeyChecking=no" bc8510@bc8510@wk1151#22@PsmpDblanVip.danskenet.net

or use :

ssh bc8510@bc8510@wk1151#22@WK0035.danskenet.net


password - you need to provide PIN+RSA generated key !!!!




wk1150
lEfJ!zTfKC9CxeP@

wk1151
aP%dOLG1cb4FsYdM

wk1152
Lgf6MQ6Jsvo@CECl

wk1153
i2jQlhGvSP0af7$u




grep -p bc8510 /etc/security/passwd
perl -le 'print scalar localtime 1599724869'
