lsuser -a unsuccessful_login_count oracle
chsec -f /etc/security/lastlog -a unsuccessful_login_count=0 -s oracle
