perl -i -pe 's/FRP000S1/FRP000P1/g' ./* 
