https://pamdb.danskenet.net

RTFM - https://confluence.danskenet.net/display/CYBHKK/Connect

connect using SSH enebles X11 forward (run browser from from jumphost).

================================================

key base authentication :

CA web go account => PSM For SSH MFA Caching;
click GENERATE
download PEM private key

change permission to 400 key.pem

use file to autentichate your connection without password :

scp -i key.pem p32399816_190000_Linux-x86-64.zip BC8510@BC8510CN%danskenet.net@ya5433.danskenet.net%22@psmpint.danskenet.net:/software

ssh -i key.pem BC8510@BC8510CN%danskenet.net@ya5433.danskenet.net%22@psmpint.danskenet.net
