
if cloud2 disk has been extended, needs to run : /opt/support/sbin/lvm_extend.sh

lvcreate -n oraswlv -L 100G datavg
lvcreate -n redo1lv -L 15G datavg
lvcreate -n redo2lv -L 15G datavg
lvcreate -n fralv -L 100G datavg
lvcreate -n dbdumplv -L 50G datavg
lvcreate -n oradatalv -l 100%FREE datavg


mkfs.xfs /dev/datavg/oraswlv
mkfs.xfs /dev/datavg/redo1lv
mkfs.xfs /dev/datavg/redo2lv
mkfs.xfs /dev/datavg/fralv
mkfs.xfs /dev/datavg/dbdumplv
mkfs.xfs /dev/datavg/oradatalv


cat >> /etc/fstab << XXX
/dev/mapper/datavg-oraswlv   /software                                xfs             defaults 0 0
/dev/mapper/datavg-redo1lv   /u01/app/oracle/oradata/RCAT/redo        xfs             defaults 0 0
/dev/mapper/datavg-redo2lv   /u02/app/oracle/oradata/RCAT/redo        xfs             defaults 0 0
/dev/mapper/datavg-fralv     /u03/app/oracle/fast_recovery_area/RCAT  xfs             defaults 0 0
/dev/mapper/datavg-dbdumplv  /u04/app/oracle/export                   xfs             defaults 0 0
/dev/mapper/datavg-oradatalv /u05/app/oracle/oradata/RCAT             xfs             defaults 0 0
XXX

mkdir -p /software
mkdir -p /u01/app/oracle/oradata/RCAT/redo
mkdir -p /u02/app/oracle/oradata/RCAT/redo
mkdir -p /u03/app/oracle/fast_recovery_area/RCAT
mkdir -p /u04/app/oracle/export
mkdir -p /u05/app/oracle/oradata/RCAT

mount -a

chown -R oracle:oinstall /software
chown -R oracle:oinstall /u01
chown -R oracle:oinstall /u02
chown -R oracle:oinstall /u03
chown -R oracle:oinstall /u04
chown -R oracle:oinstall /u05


swapoff -a
lvresize -L 16g /dev/systemvg/swaplv
mkswap /dev/systemvg/swaplv
swapon -a
free -g
