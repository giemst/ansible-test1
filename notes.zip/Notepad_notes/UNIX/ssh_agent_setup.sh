1. At the Unix prompt, enter:
  eval `ssh-agent`
  Make sure you use the backquote (`), located under the tilde (~), rather than the single quote (').

2. Enter the command:
  ssh-add
3. Enter your private key password.
4. When you log out, enter the command:
 kill $SSH_AGENT_PID
To run this command automatically when you log out, place it in your .logout file (if you are using csh or tcsh) or your .bash_logout file (if you are using bash).
