ssh bc8510@bc8510@wk1151#22@PsmpDblanVip.danskenet.net

New way from May 8

ssh BC8510@BC8510CN%danskenet.net@ya5433.danskenet.net%22@psmpint.danskenet.net

Quantex'a :

ssh BC8510@bc8510@wk1150%22@psmpint.danskenet.net 





ssh bc8510@BC8510CP%danskenet.net@oem.danskenet.net%22@psmpint.danskenet.net

scp -O BC8510@BC8510CP%danskenet.net@yb2115.danskenet.net%22@psmpint.danskenet.net:/tmp/emctl.log .

!!! MAC must use "-O"