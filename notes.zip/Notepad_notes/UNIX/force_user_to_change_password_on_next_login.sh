pwdadm -f ADMCHG [user]
