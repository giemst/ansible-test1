#!/usr/bin/expect

#Usage sshsudologin.expect <host> <ssh user> <ssh password> <su user> <su password>

set timeout 60

spawn ssh [lindex $argv 1]@[lindex $argv 0]

expect "yes/no" {
	send "yes\r"
	expect "*?assword" { send "[lindex $argv 2]\r" }
	} "*?assword" { send "[lindex $argv 2]\r" }

expect "# " { send "su - [lindex $argv 3]\r" }
expect ": " { send "[lindex $argv 4]\r" }
expect "# " { send "ls -ltr\r" }
interact

=====================================================

#!/usr/bin/expect
set username admin
set oldpass sam$$$
set newpass abc.123

spawn ssh -l $username 192.168.1.10

expect "assword:"
send "$oldpass\r"
expect "# "
sleep 1
send "passwd\r"
expect "Enter new expert password:"
send "$newpass\r"
expect "Enter new expert password (again):"
send "$newpass\r"
expect eof"
expect "# "
send "exit\n"


[admin@localhost ~]$ ./test.sh
spawn ssh -l admin 192.168.1.10
admin@192.168.1.10's password:
Last login: Thu Oct 30 18:41:52 2014 from 192.168.1.5
[Expert@cpmodule]# passwd
Enter new expert password:
Enter new expert password (again):
Expert password has been changed



==============================

#!/usr/bin/expect

set timeout 20

set cmd [lrange $argv 1 end]
set password [lindex $argv 0]

eval spawn $cmd
expect "Password:"
send "$password\r";
interact
Put it to /usr/bin/exp, then you can use:

exp <password> ssh <anything>
exp <password> scp <anysrc> <anydst>
Done!
