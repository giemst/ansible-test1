#!/usr/bin/bash

echo ""
read -p "username: " username
read -s -p "Password: " password
echo ""
read -s -p "New Password: " n1password
echo ""
read -s -p "Repeat new password: " n2password
echo ""

if [ ${password} == ${n1password} ]
then
echo "Old password cannot be reused !"
exit 0
fi

if [ ${n1password} != ${n2password} ]
then
echo "New password doesn't match repeated one !"
exit 0
fi

if [ -f 'pass_change.log' ]
then
rm pass_change.log
fi
echo "processing..."

for hostn in $(cat lpars_list.lst);
do
 ./chpwd.expect $hostn $username $password $n1password >> pass_change.log
done

grep -i failed pass_change.log
grep -i successful pass_change.log |grep host
