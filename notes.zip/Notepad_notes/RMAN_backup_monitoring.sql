run {
allocate channel t1 type sbt;
backup archivelog all delete input;
}

run {
allocate channel t1 type sbt;
allocate channel t2 type sbt;
allocate channel t3 type sbt;
allocate channel t4 type sbt;
DELETE OBSOLETE RECOVERY WINDOW OF 60 DAYS;
}


delete archivelog all completed before 'sysdate-90' backed up 1 times TO DEVICE TYPE SBT_TAPE;

select ''''||sid ||','|| serial#||',@'||inst_id ||'''' kill, start_time,totalwork, sofar, (sofar/totalwork) * 100 done,sysdate + time_remaining/3600/24 end_at from gv$session_longops
where totalwork > sofar
AND opname NOT LIKE '%aggregate%'
AND opname like 'RMAN%';

select * from v$rman_status
where session_recid = (select max(session_recid) from v$rman_status)
order by recid;


select * from v$session_wait where wait_class!='Idle' and sid in (select sid from v$session where program like 'rman%');

SELECT * FROM v$system_event WHERE event LIKE '%control%';

select output from v$rman_output where session_recid = (select max(session_recid) from v$rman_status);

select * from V$CONTROLFILE_RECORD_SECTION;

select * from v$log_history order by sequence# desc;

select * from v$recovery_area_usage;

usual rman wait during backup :
Backup: MML write backup piece
DPRO control file sequential read


emctl start blackout DB_resrtart -nodeLevel -d 1:00


=============================================================



KUP-04118: operation "pipe read", location "skudmir"

LDR_CNTRL=MAXDATA=0x80000000
export LDR_CNTRL



ssh BC8510@bc8510@wk1150.danskenet.net%22@psmpint.danskenet.net

ssh BC8510@bc8510@wk1150%22@
