RUN
{
  ALLOCATE CHANNEL disk1 DEVICE TYPE DISK FORMAT '/data/FRP000P1/backup/frp1_%d_%U';
  BACKUP AS COMPRESSED BACKUPSET DATABASE INCLUDE CURRENT CONTROLFILE;
  BACKUP AS COMPRESSED BACKUPSET archivelog all delete input;
  backup CURRENT CONTROLFILE format '/data/GMT1/backup/cntrl_%d_%U';
}

run{
ALLOCATE CHANNEL disk1 DEVICE TYPE DISK FORMAT '/data/FRP000P1/backup/frp2_stb.cnt';
BACKUP CURRENT CONTROLFILE FOR STANDBY;
}

connect auxiliary /
set dbid 1709936274;

run {
  allocate auxiliary channel t1 type disk;

  set newname for database to '/data/FRP000P2/FRP000P2/%b';
  set newname for tempfile 1 to '/data/FRP000P2/FRP000P2/temporary_data01.dbf';
  DUPLICATE TARGET DATABASE TO FRP000P2
  backup location  '/data/FRP000P1/backup'
  LOGFILE
  GROUP 1 ('/data/FRP000P2/FRP000P2/redo01.log') SIZE 200M,
  GROUP 2 ('/data/FRP000P2/FRP000P2/redo02.log') SIZE 200M,
  GROUP 3 ('/data/FRP000P2/FRP000P2/redo03.log') SIZE 200M;
}


connect auxiliary sys/Oracle1@FRP000P3_dgmgrl
connect target sys/Oracle1@FRP000P2_dgmgrl

run
{
set newname for database to '/data/FRP000P3/FRP000P3/%b';
set newname for tempfile 1 to '/data/FRP000P3/FRP000P3/temporary_data01.dbf';
DUPLICATE TARGET DATABASE FOR STANDBY FROM ACTIVE DATABASE DORECOVER ;
}




alter system set log_file_name_convert='/data/FRP000P2/FRP000P2/','/data/FRP000P3/FRP000P3/' scope=spfile;
alter system set db_file_name_convert='/data/FRP000P2/FRP000P2/','/data/FRP000P3/FRP000P3/' scope=spfile;

alter system set log_file_name_convert='/data/FRP000P3/FRP000P3/','/data/FRP000P2/FRP000P2/' scope=spfile;
alter system set db_file_name_convert='/data/FRP000P3/FRP000P3/','/data/FRP000P2/FRP000P2/' scope=spfile;


alter database add standby logfile group 4 '/data/FRP000P2/FRP000P2/stabdby_log4.log' size 200m;
alter database add standby logfile group 5 '/data/FRP000P2/FRP000P2/stabdby_log5.log' size 200m;
alter database add standby logfile group 6 '/data/FRP000P2/FRP000P2/stabdby_log6.log' size 200m;
alter database add standby logfile group 7 '/data/FRP000P2/FRP000P2/stabdby_log7.log' size 200m;

alter database add standby logfile group 4 '/data/FRP000P3/FRP000P3/stabdby_log4.log' size 200m;
alter database add standby logfile group 5 '/data/FRP000P3/FRP000P3/stabdby_log5.log' size 200m;
alter database add standby logfile group 6 '/data/FRP000P3/FRP000P3/stabdby_log6.log' size 200m;
alter database add standby logfile group 7 '/data/FRP000P3/FRP000P3/stabdby_log7.log' size 200m;







ADMINISTER KEY MANAGEMENT CREATE KEYSTORE '/software/app/oracle/admin/FRP000P2/wallet' IDENTIFIED BY "truesys123";
ADMINISTER KEY MANAGEMENT SET KEYSTORE OPEN IDENTIFIED BY "truesys123" CONTAINER=ALL;
ADMINISTER KEY MANAGEMENT SET KEYSTORE CLOSE IDENTIFIED BY "truesys123" CONTAINER=ALL;
ADMINISTER KEY MANAGEMENT SET KEY IDENTIFIED BY "truesys123" WITH BACKUP USING 'TDE Test1' CONTAINER=ALL;
ADMINISTER KEY MANAGEMENT CREATE AUTO_LOGIN KEYSTORE FROM KEYSTORE '/software/app/oracle/admin/FRP000P2/wallet' IDENTIFIED BY "truesys123";



CREATE TABLE tde_test (id    NUMBER(10),data  VARCHAR2(50) ENCRYPT) tablespace example1;
INSERT INTO tde_test VALUES (1, 'This is a secret!');
COMMIT;

CREATE TABLESPACE encrypted_ts DATAFILE '/data/FRP000P2/FRP000P2/encrypted_ts.dbf' SIZE 128K AUTOEXTEND ON NEXT 64K maxsize 1G ENCRYPTION USING 'AES256' DEFAULT STORAGE(ENCRYPT);
CREATE TABLESPACE regular_ts DATAFILE '/data/FRP000P2/FRP000P2/regular_ts.dbf' SIZE 128K AUTOEXTEND ON NEXT 64K maxsize 1G;
ALTER USER scott QUOTA UNLIMITED ON encrypted_ts;

CONN scott/tiger@gmpdb_1

CREATE TABLE tde_ts_test (id    NUMBER(10),data  VARCHAR2(50)) TABLESPACE encrypted_ts;
INSERT INTO tde_ts_test VALUES (1, 'This is also a secret!');
COMMIT;

ADMINISTER KEY MANAGEMENT BACKUP KEYSTORE USING 'TDE_bak2_' IDENTIFIED BY "Oracle1";
