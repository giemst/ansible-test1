select t.host_name host,b.property_value system,
c.property_value env, t.target_name, a.init_param_name, a.init_param_value metric from sysman.MGMT$CS_DB_INIT_PARAMS a
join sysman.mgmt$target_properties b on (a.target_guid = b.target_guid)
join sysman.mgmt$target_properties c on (a.target_guid = c.target_guid)
join sysman.mgmt$target t on (a.target_guid = t.target_guid)
where  a.init_param_name = 'filesystemio_options'
and b.property_name='orcl_gtp_line_of_bus'
and c.property_name='orcl_gtp_lifecycle_status'
and a.init_param_value!='setall'
order by 2,3,4;




select t.target_name, t.target_guid, p.property_value from sysman.mgmt$target t
left outer join sysman.mgmt$target_properties p
on (t.target_guid = p.target_guid and p.property_name='orcl_gtp_location')
where t.target_type='host';

select t.target_name, t.target_guid, p.property_value from sysman.mgmt$target t, sysman.mgmt$target_properties p
where t.target_guid = p.target_guid (+)
and t.target_type='host'
and p.property_name(+)='orcl_gtp_location';






select target_name,target_guid from sysman.mgmt$target
where target_type='host';

select target_name, target_guid, property_value from sysman.mgmt$target_properties
where target_type='host'
and property_name='orcl_gtp_location';

[‎2020-‎09-‎03 12:44]  Jurij Lavrinovic:
with a as
(select 'aaaa/bbb' name from dual
union all
select 'aaav/bbbv' name from dual
union all
select 'aaaabbb' name from dual

)


select substr(name,1,instr(name,'/')-1) from a where instr(name,'/')>0
union all
select substr(name,instr(name,'/')+1) from a where instr(name,'/')>0
