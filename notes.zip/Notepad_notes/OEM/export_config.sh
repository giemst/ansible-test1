emctl exportconfig oms -dir /u06/app/oracle/oradata/oem/export/install/OEM_backup -keep_host
