select c.property_value host,a.target_name, 
       b.property_value environment, d.property_value business, e.property_value spi, f.property_value contact
-- select *    
  from sysman.mgmt$target a
  left outer join sysman.mgmt$target_properties b on (a.target_guid=b.target_guid and b.property_name = 'orcl_gtp_lifecycle_status')
  left outer join sysman.mgmt$target_properties c on (a.target_guid=c.target_guid and c.property_name = 'MachineName')
  left outer join sysman.mgmt$target_properties d on (a.target_guid=d.target_guid and d.property_name = 'orcl_gtp_line_of_bus')
  left outer join sysman.mgmt$target_properties e on (a.target_guid=e.target_guid and e.property_name = 'orcl_gtp_cost_center')
  left outer join sysman.mgmt$target_properties f on (a.target_guid=f.target_guid and f.property_name = 'orcl_gtp_contact')
where a.target_type in ('oracle_database','host','oracle_listener','oracle_emd')
  and (b.property_value is null or d.property_value is null or e.property_value is null)
order by decode(b.property_value, 'Production',1,'Staging',2, 'Stage',2,'Test',3,4), d.property_value;