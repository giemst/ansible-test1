set serveroutput on
WHENEVER SQLERROR EXIT FAILURE;

DECLARE
 v_mp         VARCHAR2(10);
 v_dbn        VARCHAR2(30);
 v_path       VARCHAR2(100);
 v_tsn        VARCHAR2(100);
 v_stmt       VARCHAR2(400);
 v_used       NUMBER;
 v_max        NUMBER default (20);
 v_fn         NUMBER;
BEGIN

select name into v_dbn from v$database;

v_tsn := '%key_value%' ;

  select USED_PERCENT into v_used from dba_tablespace_usage_metrics where tablespace_name = v_tsn ;
  select count(file_name)+1 into v_fn from dba_data_files where tablespace_name = v_tsn ;
  select mount into v_mp from 
        (select distinct substr(file_name,1,4) "MOUNT" 
            from dba_data_files order by 1 desc) where rownum <2;

  v_path := v_mp || '/app/oracle/oradata/' || v_dbn || '/';

  while v_used > 92 and v_max >0
    loop
      v_stmt := 'ALTER TABLESPACE "' || v_tsn || '" ADD DATAFILE ''' || v_path || lower(v_tsn) || '_ad' || v_fn || '.dbf' || ''' SIZE 31G';
      dbms_output.put_line(v_stmt);
      EXECUTE IMMEDIATE v_stmt;
      v_fn := v_fn+1;
      v_max := v_max-1;
      select USED_PERCENT into v_used from dba_tablespace_usage_metrics where tablespace_name = v_tsn ;
    end loop;
END;
/


host (echo "resync catalog;" >/tmp/resync.rman ; rman target="/" catalog="/@rcat" @/tmp/resync.rman ; rm /tmp/resync.rman)