select substr(a.target_name,1,6),d.property_value,b.property_value,e.property_value from sysman.mgmt$target a
left join sysman.mgmt$target_properties d on (a.target_guid=d.target_guid and d.property_name = 'orcl_gtp_line_of_bus')
left join sysman.mgmt$target_properties b on (a.target_guid=b.target_guid and b.property_name = 'orcl_gtp_lifecycle_status')
left join sysman.mgmt$target_properties e on (a.target_guid=e.target_guid and e.property_name = 'orcl_gtp_cost_center')
where a.target_type='host' 
--and d.property_value='ALGO'
order by 2,1