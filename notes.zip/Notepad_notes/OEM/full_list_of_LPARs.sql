select distinct * from (with ahost as (
select property_value name,target_name from sysman.mgmt$target_properties
where target_type='host'
and property_name='orcl_gtp_location'
and property_value is not null)
select substr(name,1,instr(name,'/')-1)||decode (substr(target_name,instr(target_name,'.',1,2)+1),'com','.danskenet.com',null) from ahost where instr(name,'/')>0
union all
select substr(name,instr(name,'/')+1)||decode (substr(target_name,instr(target_name,'.',1,2)+1),'com','.danskenet.com',null) from ahost where instr(name,'/')>0
union all
select substr(t.target_name,1,instr(t.target_name,'.')-1) from sysman.mgmt$target t, sysman.mgmt$target_properties p
where t.target_guid = p.target_guid (+)
and t.target_type='host'
and p.property_name(+)='orcl_gtp_location'
and p.property_name is null
union all
select substr(target_name,1,instr(target_name,'.')-1) from sysman.mgmt$target_properties
where target_type='host'
and property_name='orcl_gtp_location'
and property_value is null) order by 1;
