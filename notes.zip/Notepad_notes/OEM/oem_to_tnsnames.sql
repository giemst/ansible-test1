declare 
cursor db1 is select target_name,AGENT_HOST_NAME from sysman.MGMT$AGENTS_MONITORING_TARGETS
where target_type='oracle_database';
rec1 db1%ROWTYPE;
db_name varchar2(30);
host    varchar2(60);
outas   varchar2(400);
total number;
begin
total:=0;
for rec1 in db1
loop
SYS.DBMS_OUTPUT.PUT_LINE(rec1.target_name||'=');
SYS.DBMS_OUTPUT.PUT_LINE('  (DESCRIPTION =');
SYS.DBMS_OUTPUT.PUT_LINE('    (ADDRESS = (PROTOCOL = TCP)(HOST = '||rec1.agent_host_name||')(PORT = 1521))');
SYS.DBMS_OUTPUT.PUT_LINE('    (CONNECT_DATA =');
SYS.DBMS_OUTPUT.PUT_LINE('      (SERVER = DEDICATED)');
SYS.DBMS_OUTPUT.PUT_LINE('      (SERVICE_NAME = '||rec1.target_name||') ');
SYS.DBMS_OUTPUT.PUT_LINE('    )');
SYS.DBMS_OUTPUT.PUT_LINE('   )');
SYS.DBMS_OUTPUT.PUT_LINE('');
end loop;
end;



