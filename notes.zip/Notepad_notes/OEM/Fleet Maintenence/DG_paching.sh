./emcli db_software_maintenance -getVersions -image_id=B1A0B4449D6E014CE0530A6C2422990E
./emcli db_software_maintenance -describeImage -image_id=B1A0B4449D6E014CE0530A6C2422990E


./emcli db_software_maintenance -performOperation -name="Deploy Home 18" -purpose="DEPLOY_DB_SOFTWARE" -target_type=oracle_database -target_list=GMT18S,GMT18P -normal_credential="ORACLE_SSH:BC8510" -privilege_credential="BC8510_ROOT:BC8510" -input_file="data:scripts/18_dep.prop"

./emcli db_software_maintenance -performOperation -name="Update Listener" -purpose=migrate_listener -target_type=oracle_database -target_list=GMT18P,GMT18S -normal_credential="ORACLE_SSH:BC8510" -privilege_credential="BC8510_ROOT:BC8510"

./emcli db_software_maintenance -performOperation -name="Patch Primary" -purpose="UPDATE_DB" -target_type=oracle_database -target_list=GMT18P -normal_credential="ORACLE_SSH:BC8510" -privilege_credential="BC8510_ROOT:BC8510" -dataguard_role=primary -input_file="data:scripts/prim_dep.prop"




create configuration GMT18_DG as primary database is GMT18P connect identifier is 'GMT18P_DGMGRL';
add database GMT18S as connect identifier is 'GMT18S_DGMGRL' maintained as physical;
enable configuration;
EDIT DATABASE gmt18p SET PROPERTY 'LogXptMode'='SYNC';
EDIT DATABASE gmt18s SET PROPERTY 'LogXptMode'='SYNC';
EDIT CONFIGURATION SET PROTECTION MODE AS MAXAVAILABILITY;


alter system set dg_broker_config_file1='/software/app/oracle/product/18.0.0/dbhome_3/dbs/dr1GMT18S.dat' scope=spfile;
alter system set dg_broker_config_file2='/software/app/oracle/product/18.0.0/dbhome_3/dbs/dr2GMT18S.dat' scope=spfile;


./emcli db_software_maintenance -performOperation -name="Deploy Home 19" -purpose="DEPLOY_DB_SOFTWARE" -target_type=oracle_database -target_list=QUANT0S1 -normal_credential="ORACLE_SSH:BC8510" -privilege_credential="BC8510_WK1151_ROOT:BC8510" -input_file="data:scripts/19_dep.prop"
