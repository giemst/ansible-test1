EM 13c: Fleet Maintenance report error 'Oracle Home Is Already Provisioned For This Target' (Doc ID 2470586.1)


before refresh configuration on source OH !!!!! (Doc ID 2470586.1)
./emcli db_software_maintenance -createSoftwareImage -input_file=data:scripts/122_upd.prop
./emcli db_software_maintenance -getImages
./emcli db_software_maintenance -getVersions -image_id=B239AEC0BEEF016EE0530A6C242282CA
./emcli db_software_maintenance -updateVersionStatus -version_id=B35D286ACC18014CE0530A6C24229D72 -status=CURRENT
./emcli db_software_maintenance -getVersions -image_id=B020B034BB39015AE0530A6C2422EB37
