How To Patch Or Upgrade Standalone Database Using Fleet Maintenance (Doc ID 2434260.1)


==========Subscribe_targets=============

./emcli db_software_maintenance -checkApplicability -image_id=B0202F1E8DD501BEE0530A6C242252BB -target_list=ORCL -target_type=oracle_database
./emcli db_software_maintenance -subscribeTarget -target_name=ORCL -target_type=oracle_database -image_id=B0202F1E8DD501BEE0530A6C242252BB
./emcli db_software_maintenance -getTargetSubscriptions -target_name=ORCL -target_type=oracle_database
./emcli db_software_maintenance -getImageSubscriptions -image_id=B020B034BB39015AE0530A6C2422EB37

==========Deploy_image===================

./emcli db_software_maintenance -performOperation -name="Deploy Home 121" -purpose="DEPLOY_DB_SOFTWARE" -target_type=oracle_database -target_list=GMT18S,GMT18P -normal_credential="ORACLE_SSH:BC8510" -privilege_credential="BC8510_ROOT:BC8510" -input_file="data:scripts/18_dep.prop"

 -start_schedule="start_time:2020/10/14 13:50"

==========Patch_single_instance===========


./emcli db_software_maintenance -performOperation -name="patch_ORCL" -purpose="UPDATE_DB" -target_type=oracle_database -target_list=GMT122 -normal_credential="ORACLE_SSH:BC8510" -privilege_credential="BC8510_ROOT:BC8510" -database_credential=BC8510_SYSDBA:BC8510


==========Dataguard_patching=============

---Update_standby_database---

./emcli db_software_maintenance -performOperation -name="Patch Standby" -purpose="UPDATE_DB" -target_type=oracle_database -target_list=GMT18S -normal_credential="ORACLE_SSH:BC8510" -privilege_credential="BC8510_ROOT:BC8510" -dataguard_role=standby -input_file="data:scripts/stb_dep.prop"

## content of stb_dep.prop
workingDir=<Name of temp directory>
disableDG=<true|false>. The default value is false. This should be set to ‘true’ if the standby is managed by Data Guard

---Update_primary_database---
./emcli db_software_maintenance -performOperation -name="Patch Primary" -purpose="UPDATE_DB" -target_type=oracle_database -target_list=GMT18P -normal_credential="ORACLE_SSH:BC8510" -privilege_credential="BC8510_ROOT:BC8510" -dataguard_role=primary -input_file="data:scripts/prim_dep.prop"

## content of prim_dep.prop
workingDir=<Name of temp directory>
enableDG=<true|false> The default value is false. This should be set to ‘true’ if the standby is managed by Data Guard.

==========Cleanup=========================


wk1001      OraDB18Home1_5_wk1001.danskenet.net_9733
wk1002     Orasidb12c_home1_2020_10_16_09_51_8_wk1002.danskenet.net_6333

./emcli db_software_maintenance -performOperation -name="cleanup" -purpose="CLEANUP_SOFTWARE" -target_list=Orasidb12c_home1_2020_10_16_09_51_8_wk1002.danskenet.net_6333 -target_type=oracle_home -normal_credential="ORACLE_SSH:BC8510" -privilege_credential="BC8510_ROOT:BC8510" -workDir=/export/install/EM_stage

./emcli db_software_maintenance -performOperation -name="cleanup" -purpose="CLEANUP_SOFTWARE" -target_list=OraDB18Home1_5_wk1002.danskenet.net_9733 -target_type=oracle_home -normal_credential="ORACLE_SSH:BC8510" -privilege_credential="BC8510_ROOT:BC8510" -workDir=/export/install/EM_stage



================Rollback==================

./emcli db_software_maintenance -performOperation -name="rollback Standby" -purpose="ROLLBACK_DB" -target_type=oracle_database -target_list=GMT18S -normal_credential="ORACLE_SSH:BC8510" -privilege_credential="BC8510_ROOT:BC8510" -dataguard_role=standby -input_file="data:scripts/stb_dep.prop"

./emcli db_software_maintenance -performOperation -name="rollback Listener" -purpose=migrate_listener -target_type=oracle_database -target_list=GMT18S -normal_credential="ORACLE_SSH:BC8510" -privilege_credential="BC8510_ROOT:BC8510"

./emcli db_software_maintenance -performOperation -name="rollback Primary" -purpose="ROLLBACK_DB" -target_type=oracle_database -target_list=GMT18P -normal_credential="ORACLE_SSH:BC8510" -privilege_credential="BC8510_ROOT:BC8510" -dataguard_role=primary -input_file="data:scripts/prim_dep.prop"
