emctl setproperty agent -allow_new -name CollectionResults.MaximumRowsFloodControlMin -value 10000
emctl setproperty agent -allow_new -name CollectionResults.MaximumRowsFloodControlMax -value 20000
emctl reload agent
emctl control agent runCollection OraHome1_1_wk1167.danskenet.net_6333:oracle_home 'oracle_home_config'

/software/app/oracle/product/agent/GoldImage_agent_200131/agent_13.3.0.0.0
