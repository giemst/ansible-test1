conn = cx_Oracle.connect("ansible/ansible@192.168.1.232:1521/ORCLPDB1")

for i in range(0, 1):
    a_str1 = ''.join(random.choice(string.ascii_letters) for i in range(100))
    a_num1 =  ''.join(random.choice(string.digits) for i in range(15))
    random_date = datetime.date(1920, 1, 1) + datetime.timedelta(days=random.randrange(365*150))

    print(a_num1,random_date, a_str1 )