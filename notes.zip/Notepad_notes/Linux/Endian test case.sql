Endian test case :


create tablespace xxt_ts datafile '/u05/app/oracle/oradata/AIL/xxt_ts.dbf' size 5m;
create user xtt_test identified by xtt_test;
grant create session, create table to xtt_test;
alter user xtt_test quota unlimited on xxt_ts;

create table test1 (id number, cdate date, rdata varchar2(100)) tablespace xxt_ts;

begin
for a in 1 .. 11
loop
    insert into test1 values (a, sysdate+a, to_char(sysdate+a,'yyyy.mm.dd-hh24:mi:ss'));
end loop;
commit;
end;

alter tablespace xxt_ts read only;

userid="/ as sysdba"
dumpfile=xttdump.dmp
directory=linux_mig
exclude=statistics
transport_tablespaces=xxt_ts
transport_full_check=y
logfile=tts_export.log 

export ORACLE_PDB_SID=ORCLPDB1

userid="/ as sysdba"
dumpfile= xttdump.dmp
directory=linux_mig
transport_datafiles='/u05/app/oracle/oradata/AIL/xxt_ts.dbf'
logfile=tts_import.log


Processing object type TRANSPORTABLE_EXPORT/PLUGTS_BLK
ORA-01141: error renaming data file 



AIX-Based Systems (64-bit)

rman>
convert datafile '/opt/oracle/oradata/ORCLCDB/ORCLPDB1/xxt_ts.dbf_AIX'
TO PLATFORM="Linux x86 64-bit"
FROM PLATFORM="AIX-Based Systems (64-bit)"
FORMAT '/opt/oracle/oradata/ORCLCDB/ORCLPDB1/xxt_ts.dbf'


Starting "SYSTEM"."SYS_IMPORT_TRANSPORTABLE_01":  system/********@orclpdb1 parfile=imp.par 
Processing object type TRANSPORTABLE_EXPORT/PLUGTS_BLK
ORA-39123: Data Pump transportable tablespace job aborted
ORA-01141: error renaming data file /opt/oracle/oradata/ORCLCDB/ORCLPDB1/xxt_ts.dbf - new file '' not found
ORA-27048: skgfifi: file header information is invalid
Additional information: 2


-rw-r-----    1 oracle   dba       629153792 Aug 28 2019  ./AIL/AIL_temp01.dbf
-rw-r-----    1 oracle   dba      33286004736 Feb 11 2020  ./EPTH/EPTH_temp01.dbf
-rw-r-----    1 oracle   dba      33286004736 Feb 25 2020  ./EPTH/EPTH_temp02.dbf
-rw-r-----    1 oracle   dba      4194312192 Aug 28 2019  ./FARM/FARM_temp01.dbf
-rw-r-----    1 oracle   dba      33286004736 Feb 20 2020  ./IPDB/IPDB_temp01.dbf
-rw-r-----    1 oracle   dba      33286004736 Aug 28 2019  ./IPDB/IPDB_temp02.dbf
-rw-r-----    1 oracle   dba        52436992 Aug 28 2019  ./IPDB/IPDB_temp03.dbf
-rw-r-----    1 oracle   dba      33286004736 Aug 27 2019  ./ODS/ODS_temp01.dbf
-rw-r-----    1 oracle   dba      33286004736 Aug 27 2019  ./ODS/ODS_temp02.dbf
-rw-r-----    1 oracle   dba      33286004736 Aug 27 2019  ./ODS/ODS_temp03.dbf
-rw-r-----    1 oracle   dba      33286004736 Feb 23 2020  ./OPTI/OPTI_temp01.dbf

col file_name for a60
set pages 200 lines 200
select file_name, BYTES/1024/1024, AUTOEXTENSIBLE, MAXBYTES/1024/1024, INCREMENT_BY from dba_data_files;

alter database datafile '/u05/app/oracle/oradata/EPTH/undotbs01.dbf' RESIZE 2g;
alter database datafile '/u05/app/oracle/oradata/EPTH/undotbs01.dbf'AUTOEXTEND on next 250m maxsize unlimited;

select file_name, BYTES/1024/1024, AUTOEXTENSIBLE, MAXBYTES/1024/1024, INCREMENT_BY from dba_temp_files;

alter database tempfile '/u05/app/oracle/oradata/EPTH/temp01.dbf' RESIZE 2g;
alter database tempfile '/u05/app/oracle/oradata/EPTH/temp01.dbf'AUTOEXTEND on next 1g maxsize unlimited;

alter tablespace temp add tempfile '/u05/app/oracle/oradata/EPTH/temp02.dbf' size 2g autoextend on next 1g maxsize unlimited;