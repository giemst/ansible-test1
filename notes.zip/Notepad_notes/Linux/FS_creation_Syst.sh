
lvcreate -n redo11lv -L 12G datavg
lvcreate -n redo12lv -L 12G datavg
lvcreate -n redo13lv -L 12G datavg
lvcreate -n redo14lv -L 12G datavg
lvcreate -n redo15lv -L 12G datavg
lvcreate -n redo16lv -L 12G datavg

lvcreate -n redo21lv -L 12G datavg
lvcreate -n redo22lv -L 12G datavg
lvcreate -n redo23lv -L 12G datavg
lvcreate -n redo24lv -L 12G datavg
lvcreate -n redo25lv -L 12G datavg
lvcreate -n redo26lv -L 12G datavg

lvcreate -n fra1lv -L 50G datavg
lvcreate -n fra2lv -L 50G datavg
lvcreate -n fra3lv -L 50G datavg
lvcreate -n fra4lv -L 50G datavg
lvcreate -n fra5lv -L 50G datavg
lvcreate -n fra6lv -L 50G datavg

lvcreate -n oradata1lv -L 22G datavg
lvcreate -n oradata2lv -L 1700G datavg
lvcreate -n oradata3lv -L 470G datavg
lvcreate -n oradata4lv -L 800G datavg
lvcreate -n oradata5lv -L 3500G datavg
lvcreate -n oradata6lv -L 500G datavg

lvcreate -n oraswlv -L 100G datavg

lvcreate -n dbdumplv -L 3000G datavg


mkfs.xfs /dev/datavg/redo11lv
mkfs.xfs /dev/datavg/redo12lv
mkfs.xfs /dev/datavg/redo13lv
mkfs.xfs /dev/datavg/redo14lv
mkfs.xfs /dev/datavg/redo15lv
mkfs.xfs /dev/datavg/redo16lv

mkfs.xfs /dev/datavg/redo21lv
mkfs.xfs /dev/datavg/redo22lv
mkfs.xfs /dev/datavg/redo23lv
mkfs.xfs /dev/datavg/redo24lv
mkfs.xfs /dev/datavg/redo25lv
mkfs.xfs /dev/datavg/redo26lv

mkfs.xfs /dev/datavg/fra1lv
mkfs.xfs /dev/datavg/fra2lv
mkfs.xfs /dev/datavg/fra3lv
mkfs.xfs /dev/datavg/fra4lv
mkfs.xfs /dev/datavg/fra5lv
mkfs.xfs /dev/datavg/fra6lv

mkfs.xfs /dev/datavg/oradata1lv
mkfs.xfs /dev/datavg/oradata2lv
mkfs.xfs /dev/datavg/oradata3lv
mkfs.xfs /dev/datavg/oradata4lv
mkfs.xfs /dev/datavg/oradata5lv
mkfs.xfs /dev/datavg/oradata6lv

mkfs.xfs /dev/datavg/oraswlv

mkfs.xfs /dev/datavg/dbdumplv

cat >> /etc/fstab << XXX
/dev/mapper/datavg-redo11lv  /u01/app/oracle/oradata/AIL/redo             xfs             defaults 0 0 
/dev/mapper/datavg-redo12lv  /u01/app/oracle/oradata/EPTH/redo            xfs             defaults 0 0 
/dev/mapper/datavg-redo13lv  /u01/app/oracle/oradata/FARM/redo            xfs             defaults 0 0 
/dev/mapper/datavg-redo14lv  /u01/app/oracle/oradata/IPDB/redo            xfs             defaults 0 0 
/dev/mapper/datavg-redo15lv  /u01/app/oracle/oradata/ODS/redo             xfs             defaults 0 0 
/dev/mapper/datavg-redo16lv  /u01/app/oracle/oradata/OPTI/redo            xfs             defaults 0 0 
/dev/mapper/datavg-redo21lv  /u02/app/oracle/oradata/AIL/redo             xfs             defaults 0 0        
/dev/mapper/datavg-redo22lv  /u02/app/oracle/oradata/EPTH/redo            xfs             defaults 0 0        
/dev/mapper/datavg-redo23lv  /u02/app/oracle/oradata/FARM/redo            xfs             defaults 0 0        
/dev/mapper/datavg-redo24lv  /u02/app/oracle/oradata/IPDB/redo            xfs             defaults 0 0        
/dev/mapper/datavg-redo25lv  /u02/app/oracle/oradata/ODS/redo             xfs             defaults 0 0        
/dev/mapper/datavg-redo26lv  /u02/app/oracle/oradata/OPTI/redo            xfs             defaults 0 0        
/dev/mapper/datavg-fra1lv    /u03/app/oracle/fast_recovery_area/AIL       xfs             defaults 0 0        
/dev/mapper/datavg-fra2lv    /u03/app/oracle/fast_recovery_area/EPTH      xfs             defaults 0 0            
/dev/mapper/datavg-fra3lv    /u03/app/oracle/fast_recovery_area/FARM      xfs             defaults 0 0            
/dev/mapper/datavg-fra4lv    /u03/app/oracle/fast_recovery_area/IPDB      xfs             defaults 0 0            
/dev/mapper/datavg-fra5lv    /u03/app/oracle/fast_recovery_area/ODS       xfs             defaults 0 0        
/dev/mapper/datavg-fra6lv    /u03/app/oracle/fast_recovery_area/OPTI      xfs             defaults 0 0            
/dev/mapper/datavg-oradata1lv   /u05/app/oracle/oradata/AIL               xfs             defaults 0 0  
/dev/mapper/datavg-oradata2lv   /u05/app/oracle/oradata/EPTH              xfs             defaults 0 0      
/dev/mapper/datavg-oradata3lv   /u05/app/oracle/oradata/FARM              xfs             defaults 0 0      
/dev/mapper/datavg-oradata4lv   /u05/app/oracle/oradata/IPDB              xfs             defaults 0 0      
/dev/mapper/datavg-oradata5lv   /u05/app/oracle/oradata/ODS               xfs             defaults 0 0  
/dev/mapper/datavg-oradata6lv   /u05/app/oracle/oradata/OPTI              xfs             defaults 0 0      
/dev/mapper/datavg-oraswlv      /software                                 xfs             defaults 0 0
/dev/mapper/datavg-dbdumplv     /u04/app/oracle/export                    xfs             defaults 0 0 
XXX

mkdir -p /u01/app/oracle/oradata/AIL/redo
mkdir -p /u01/app/oracle/oradata/EPTH/redo
mkdir -p /u01/app/oracle/oradata/FARM/redo
mkdir -p /u01/app/oracle/oradata/IPDB/redo
mkdir -p /u01/app/oracle/oradata/ODS/redo
mkdir -p /u01/app/oracle/oradata/OPTI/redo

mkdir -p /u02/app/oracle/oradata/AIL/redo
mkdir -p /u02/app/oracle/oradata/EPTH/redo
mkdir -p /u02/app/oracle/oradata/FARM/redo
mkdir -p /u02/app/oracle/oradata/IPDB/redo
mkdir -p /u02/app/oracle/oradata/ODS/redo
mkdir -p /u02/app/oracle/oradata/OPTI/redo

mkdir -p /u03/app/oracle/fast_recovery_area/AIL
mkdir -p /u03/app/oracle/fast_recovery_area/EPTH
mkdir -p /u03/app/oracle/fast_recovery_area/FARM
mkdir -p /u03/app/oracle/fast_recovery_area/IPDB
mkdir -p /u03/app/oracle/fast_recovery_area/ODS
mkdir -p /u03/app/oracle/fast_recovery_area/OPTI

mkdir -p /u05/app/oracle/oradata/AIL
mkdir -p /u05/app/oracle/oradata/EPTH
mkdir -p /u05/app/oracle/oradata/FARM
mkdir -p /u05/app/oracle/oradata/IPDB
mkdir -p /u05/app/oracle/oradata/ODS
mkdir -p /u05/app/oracle/oradata/OPTI

mkdir -p /software

mkdir -p /u04/app/oracle/export

mount -a

chown -R oracle:oinstall /software
chown -R oracle:oinstall /u01
chown -R oracle:oinstall /u02
chown -R oracle:oinstall /u03
chown -R oracle:oinstall /u04
chown -R oracle:oinstall /u05


swapoff -a
lvresize -L 16g /dev/systemvg/swaplv
mkswap /dev/systemvg/swaplv
swapon -a
free -g