./runInstaller -ignoreInternalDriverError

dbca -J-Doracle.assistants.dbca.validate.ConfigurationParams=false
