
yum -y remove oracle-database-ee-19c

deinstall fails with :
./deinstall: line 264: /tmp/deinstall2015-09-28_02-34-42PM/perl/bin/perl: Permission denied

needs to remount /tmp with EXEC option and then run deintall

mount -o remount,exec /tmp

change back /tmp to noexec :

mount -o remount,noexec /tmp
