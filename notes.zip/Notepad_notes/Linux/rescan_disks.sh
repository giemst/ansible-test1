lsblk
echo 1 > /sys/block/sdb/device/rescan
pvresize /dev/sdb
lvextend -l +100%FREE oradata6lv 
resize2fs oradata6lv 

lsblk