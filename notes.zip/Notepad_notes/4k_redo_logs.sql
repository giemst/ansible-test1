alter system set "_disk_sector_size_override"=TRUE scope=both;

ALTER DATABASE ADD LOGFILE GROUP 4 ('/u01/app/oracle/oradata/RCAT/redo/redo04a.log','/u02/app/oracle/oradata/RCAT/redo/redo04b.log') SIZE 200M BLOCKSIZE 4k;
ALTER DATABASE ADD LOGFILE GROUP 5 ('/u01/app/oracle/oradata/RCAT/redo/redo05a.log','/u02/app/oracle/oradata/RCAT/redo/redo05b.log') SIZE 200M BLOCKSIZE 4k;

ALTER DATABASE ADD LOGFILE GROUP 1 ('/u01/app/oracle/oradata/RCAT/redo/redo01a.log','/u02/app/oracle/oradata/RCAT/redo/redo01b.log') SIZE 200M BLOCKSIZE 4k;
ALTER DATABASE ADD LOGFILE GROUP 2 ('/u01/app/oracle/oradata/RCAT/redo/redo02a.log','/u02/app/oracle/oradata/RCAT/redo/redo02b.log') SIZE 200M BLOCKSIZE 4k;
ALTER DATABASE ADD LOGFILE GROUP 3 ('/u01/app/oracle/oradata/RCAT/redo/redo03a.log','/u02/app/oracle/oradata/RCAT/redo/redo03b.log') SIZE 200M BLOCKSIZE 4k;

